import '../App.css';

function Create() {
  return (
    <div className="Create">

    </div>
  );
}

export default Create;
