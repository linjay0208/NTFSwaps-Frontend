
export default function SwapIcon(props) {
  return (
    <img src="/Logo_icon_white.svg" width="24" height="24"/>
  );
}
